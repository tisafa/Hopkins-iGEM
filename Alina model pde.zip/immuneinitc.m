function u0 = immuneinitc(x)
% v = [T P S U G A B]
% initial conditions, ie at (x,0)
global P0_guess w_guess
P_0 = P0_guess*max(0,1-w_guess*x*x);
U_0 = 1;
T_0 = 1;
u0 = [T_0;P_0;0;U_0;0;0;0];
end

