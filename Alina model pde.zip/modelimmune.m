global q np_0 mu_p mG Ds n_1 mu_u mu_s delta_G delta_A P0_guess w_guess mu_1
q= 0.02;
np_0 = 5e-4;
mu_p = 0.002;
mG = 0.002;
Ds = 0.1;
n_1 = 1;
mu_u = 0.1;
mu_s = 0.1;
delta_G = 1;
delta_A = 1;
P0_guess = 2;
w_guess = 10;
mu_1 = 0.1;

x = linspace(0,1,100);
t = linspace(0,7,120);
m = 0;
sol = pdepe(m,@pdeimmuneDiffEqs,@immuneinitc,@immunebc,x,t);
T = sol(:,:,1);
P = sol(:,:,2);
S = sol(:,:,3);
U = sol(:,:,4);
G = sol(:,:,5);
A = sol(:,:,6);
B = sol(:,:,7);

subplot(2,1,1)
surf(x,t,T);
title('T(x,t)');
xlabel('Distance x');
ylabel('Time t');
subplot(2,1,2)
surf(x,t,P);
title('P(x,t)');
xlabel('Distance x');
ylabel('Time t');

%https://www.math.tamu.edu/~phoward/m401/pdemat.pdf
% https://www.mathworks.com/help/matlab/math/solve-system-of-pdes.html



