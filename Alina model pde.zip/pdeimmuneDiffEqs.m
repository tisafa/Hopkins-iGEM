function [c,f,s] = pdeimmuneDiffEqs(x,t,u,dudx)
% u is the uector of the system of functions. dudx= du/dx
%  u = [T P S U G A B]
global q np_0 mu_p mG Ds n_1 mu_u mu_s delta_G delta_A mu_1
c = ones(7,1);
f = [0;-1*np_0*((1-x^20)^3)*u(2)*dudx(1);Ds*dudx(3);-1*u(4)*n_1*dudx(3);-1*u(5)*n_1*dudx(3);-1*u(6)*n_1*dudx(3);0];
s = [-q*u(1)*u(2);q*u(1)*u(2)+mu_p+mG*u(5)+0.5*mG*u(6);u(1)*u(2)-mu_s*u(3);mu_u*(1-u(4))-(delta_G+delta_A)*u(3)*u(4);delta_G*u(3)*u(4)-mu_1*u(5);delta_A*u(3)*u(4)-mu_1*u(6);u(6)];
end

