
function [pl,ql,pr,qr] = immunebc(xl,ul,xr,ur,t)
pl = zeros(7,1);
ql = ones(7,1);
pr = zeros(7,1);
qr = ones(7,1);
end